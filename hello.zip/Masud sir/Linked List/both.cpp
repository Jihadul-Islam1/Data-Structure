#include <iostream>
using namespace std;

class Node {
public:
    int val;
    Node* next;

    Node(int val) {
        this->val = val;
        this->next = NULL;
    }
};

class LinkedList {
private:
    Node* head;

public:
    LinkedList() {
        head = NULL;
    }

    void insertAtHead(int item) {
        Node* newNode = new Node(item);
        newNode->next = head;
        head = newNode;
    }

    void insertAtPosition(int position, int item) {
        if (position == 1) {
            insertAtHead(item);
            return;
        }

        Node* newNode = new Node(item);
        Node* temp = head;

        for (int i = 1; i < position - 1 && temp != NULL; i++) {
            temp = temp->next;
        }

        if (temp == NULL) {
            cout << "Position out of bounds. Inserting at the end." << endl;
            delete newNode; // avoid memory leak
            return;
        }

        newNode->next = temp->next;
        temp->next = newNode;
    }

    void deleteNode(int position) {
        if (head == NULL) {
            cout << "List is empty, nothing to delete." << endl;
            return;
        }

        if (position == 1) {
            Node* temp = head;
            head = head->next;
            delete temp;
            cout << "Deleted from head." << endl;
            return;
        }

        Node* temp = head;
        for (int i = 1; i < position - 1 && temp != NULL; i++) {
            temp = temp->next;
        }

        if (temp == NULL || temp->next == NULL) {
            cout << "Position out of bounds." << endl;
            return;
        }

        Node* nodeToDelete = temp->next;
        temp->next = nodeToDelete->next;
        delete nodeToDelete;
        cout << "Deleted from position " << position << "." << endl;
    }

    void printList() {
        if (head == NULL) {
            cout << "List is empty." << endl;
            return;
        }
        Node* temp = head;
        while (temp != NULL) {
            cout << temp->val << " -> ";
            temp = temp->next;
        }
        cout << "NULL" << endl;
    }

    ~LinkedList() {
        while (head != NULL) {
            Node* temp = head;
            head = head->next;
            delete temp;
        }
    }
};

int main() {
    LinkedList list;

    // Inserting values
    while (true) {
        int item, position;
        cout << "Enter value to insert (-1 to exit): ";
        cin >> item;

        if (item == -1) {
            break;
        }

        cout << "Enter position to insert: ";
        cin >> position;

        list.insertAtPosition(position, item);
        cout << "Updated Linked List: ";
        list.printList();
    }

    // Deleting values
    while (true) {
        int position;
        cout << "\nEnter the position to delete from (or enter 0 to exit): ";
        cin >> position;

        if (position == 0) {
            break;
        }

        list.deleteNode(position);
        cout << "List after deletion: ";
        list.printList();
    }

    cout << "Program exited." << endl;
    return 0;
}
