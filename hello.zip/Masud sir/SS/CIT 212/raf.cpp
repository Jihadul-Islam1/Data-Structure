#include <bits/stdc++.h>
using namespace std;
const int INF = 1e7;
// const int N = 1e5 + 5;

struct Edge
{
    int source, destination, weight;
};

vector<int> bellmanford(int source, int n, vector<Edge> &edges)
{
    vector<int> dist(n, INF);
    dist[source] = 0;

    for (int i = 0; i < n - 1; i++)
    {
        for (const auto &edge : edges){
            if (dist[edge.source]!=INF && dist[edge.source]+edge.weight<dist[edge.destination])
            {
                dist[edge.destination] = dist[edge.source]+edge.weight;
            }
            
        }
    }

    for (const auto &edge : edges){
            if (dist[edge.source]!=INF && dist[edge.source]+edge.weight<dist[edge.destination])
            {
                cout<<"Negative cycle"<<endl;
                return {};
            }
            
    }
    return dist;
}
int main()
{
    int n, e;
    cin >> n >> e;

    vector<Edge> edges(e);

    cout << "Enter each edge (source, destination, weight):" << endl;

    for (int i = 0; i < e; i++)
    {
        int a, b, w;
        cin >> a >> b >> w;
        edges[i] = {a, b, w};
    }

    int src;
    cin >> src;

    vector<int> distance = bellmanford(src, n, edges);

    if (!distance.empty())
    {
        for (int i = 0; i < n; i++)
        {
            cout << "Distance from " << src << " to " << i <<":"<< ((distance[i] == INF) ? -1 : distance[i] )<< endl;
        }
    }
}