#include <iostream>
using namespace std;

// TreeNode structure definition
struct TreeNode {
    int value;
    TreeNode* left;
    TreeNode* right;

    TreeNode(int val) : value(val), left(nullptr), right(nullptr) {}
};

// Pre-order traversal function
void preorderTraversal(TreeNode* root) {
    if (root == nullptr) {
        return;
    }

    cout << root->value << " "; // Visit the root
    preorderTraversal(root->left); // Traverse the left subtree
    preorderTraversal(root->right); // Traverse the right subtree
}

// In-order traversal function
void inorderTraversal(TreeNode* root) {
    if (root == nullptr) {
        return;
    }
    
    inorderTraversal(root->left); // Traverse the left subtree
    cout << root->value << " "; // Visit the root
    inorderTraversal(root->right); // Traverse the right subtree
}

// Post-order traversal function
void postorderTraversal(TreeNode* root) {
    if (root == nullptr) {
        return;
    }
    
    postorderTraversal(root->left); // Traverse the left subtree
    postorderTraversal(root->right); // Traverse the right subtree
    cout << root->value << " "; // Visit the root
}

// Function to delete the tree and free memory
void deleteTree(TreeNode* root) {
    if (root == nullptr) {
        return;
    }

    deleteTree(root->left);
    deleteTree(root->right);
    delete root;
}

// Main function
int main() {
    // Create a sample tree:
    //       1
    //      / \
    //     2   3
    //    / \
    //   4   5
    
    TreeNode* root = new TreeNode(1);
    root->left = new TreeNode(2);
    root->right = new TreeNode(3);
    root->left->left = new TreeNode(4);
    root->left->right = new TreeNode(5);

    cout << "Preorder Traversal: ";
    preorderTraversal(root);
    cout << endl;

    cout << "Inorder Traversal: ";
    inorderTraversal(root);
    cout << endl;

    cout << "Postorder Traversal: ";
    postorderTraversal(root);
    cout << endl;

    // Clean up memory
    deleteTree(root);
    
    return 0;
}
