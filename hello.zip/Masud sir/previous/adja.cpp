#include <iostream>
#include <vector>

using namespace std;

// Function to initialize the adjacency matrix
void initializeMatrix(int** matrix, int M) {
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < M; j++) {
            matrix[i][j] = 0; // Initialize all values to 0
        }
    }
}

// Function to print the adjacency matrix
void printMatrix(int** matrix, int M) {
    cout << "Adjacency Matrix:" << endl;
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < M; j++) {
            cout << matrix[i][j] << " ";
        }
        cout << endl;
    }
}

// Main function to construct and display the adjacency matrix
int main() {
    // Test case 1
    int M1 = 5, N1 = 8;
    vector<pair<int, int>> edges1 = {{3, 4}, {5, 3}, {2, 4}, {1, 5}, {3, 2}, {4, 2}, {3, 1}, {5, 1}};

    // Create and initialize the adjacency matrix for the first graph
    int** adjacencyMatrix1 = new int*[M1];
    for (int i = 0; i < M1; i++) {
        adjacencyMatrix1[i] = new int[M1];
    }
    initializeMatrix(adjacencyMatrix1, M1);

    // Populate the adjacency matrix based on edges
    for (const auto& edge : edges1) {
        int from = edge.first - 1; // Convert to 0-based index
        int to = edge.second - 1;   // Convert to 0-based index
        adjacencyMatrix1[from][to] = 1; // Set the edge
    }

    // Print the adjacency matrix for the first graph
    printMatrix(adjacencyMatrix1, M1);

    // Clean up memory for the first graph
    for (int i = 0; i < M1; i++) {
        delete[] adjacencyMatrix1[i];
    }
    delete[] adjacencyMatrix1;

    // Test case 2
    int M2 = 6, N2 = 10;
    vector<pair<int, int>> edges2 = {{1, 6}, {2, 1}, {2, 3}, {3, 5}, {4, 5}, {4, 2}, {2, 6}, {5, 3}, {4, 3}, {6, 4}};

    // Create and initialize the adjacency matrix for the second graph
    int** adjacencyMatrix2 = new int*[M2];
    for (int i = 0; i < M2; i++) {
        adjacencyMatrix2[i] = new int[M2];
    }
    initializeMatrix(adjacencyMatrix2, M2);

    // Populate the adjacency matrix based on edges
    for (const auto& edge : edges2) {
        int from = edge.first - 1; // Convert to 0-based index
        int to = edge.second - 1;   // Convert to 0-based index
        adjacencyMatrix2[from][to] = 1; // Set the edge
    }

    // Print the adjacency matrix for the second graph
    printMatrix(adjacencyMatrix2, M2);

    // Clean up memory for the second graph
    for (int i = 0; i < M2; i++) {
        delete[] adjacencyMatrix2[i];
    }
    delete[] adjacencyMatrix2;

    return 0;
}

