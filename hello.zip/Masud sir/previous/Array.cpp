#include <iostream>
#include <string>
using namespace std;

int main() {
    string List[10] = {"BBBB", "DDDD", "MMMM", "XXXX"};
    int n = 4; // Current number of elements

    // Part (a): Take names to add from the user
    string nameToAdd;
    for (int i = 0; i < 2; i++) {  // We need to add 2 names
        cout << "Enter a name to add: ";
        getline(cin, nameToAdd);

        int pos = n;  // Position to insert at the end initially
        for (int j = 0; j < n; j++) {
            if (List[j] > nameToAdd) {
                pos = j;  // Find correct position to keep sorted
                break;
            }
        }

        // Shift elements to make space for the new name
        for (int j = n; j > pos; j--) {
            List[j] = List[j - 1];
        }

        List[pos] = nameToAdd;  // Insert the new name
        n++;  // Increase the count of elements
    }

    // Display the list after adding names
    cout << "After adding names: ";
    for (int i = 0; i < n; i++) {
        cout << List[i] << " ";
    }
    cout << endl;

    // Part (b): Take name to delete from the user
    string nameToDelete;
    cout << "Enter a name to delete: ";
    getline(cin, nameToDelete);
    
    int delPos = -1;
    for (int i = 0; i < n; i++) {
        if (List[i] == nameToDelete) {
            delPos = i;  // Find the position of the name
            break;
        }
    }

    // Shift elements to fill the gap after deletion
    if (delPos != -1) {  // If found
        for (int i = delPos; i < n - 1; i++) {
            List[i] = List[i + 1];
        }
        n--;  // Decrease the count of elements
    }

    // Display the list after deletion
    cout << "After deleting " << nameToDelete << ": ";
    for (int i = 0; i < n; i++) {
        cout << List[i] << " ";
    }
    cout << endl;

    return 0;
}
