#include <iostream>
#include <stack>
#include <sstream>
#include <vector>
#include <string>

using namespace std;

int evaluatePostfix(const string& expression) {
    stack<int> s;
    stringstream ss(expression);
    string token;

    while (ss >> token) {
        // If the token is an operand (number), push it onto the stack
        if (isdigit(token[0])) {
            s.push(stoi(token)); // Convert string to integer and push
        } else {
            // The token is an operator, pop two operands from the stack
            int operand2 = s.top(); s.pop(); // Second operand
            int operand1 = s.top(); s.pop(); // First operand
            
            // Perform the operation
            switch (token[0]) {
                case '+':
                    s.push(operand1 + operand2);
                    break;
                case '-':
                    s.push(operand1 - operand2);
                    break;
                case '*':
                    s.push(operand1 * operand2);
                    break;
                case '/':
                    s.push(operand1 / operand2);
                    break;
                default:
                    cout << "Invalid operator: " << token << endl;
                    return 0; // Return 0 for invalid operators
            }
        }
    }

    // The final result is on the top of the stack
    return s.top();
}

int main() {
    // Given postfix expression
    string postfixExpression = "3 1 + 2 * 1 7 + 4 2 + 5 -";
    
    // Evaluate the postfix expression
    int result = evaluatePostfix(postfixExpression);
    
    cout << "Result of the postfix expression \"" << postfixExpression << "\" is: " << result << endl;

    return 0;
}
