#include <iostream>
using namespace std;

// Recursive function Q(J, K)
int Q(int J, int K) {
    // Base case: if J is not less than K, return J
    if (J >= K) {
        return J;
    } else {
        // Recursive case: J + Q(J-K, K-2)
        return J + Q(J - K, K - 2);
    }
}

int main() {
    // Test the function with given values
    cout << "Q(12, 7) = " << Q(12, 7) << endl;  // Example test case
    cout << "Q(25, 30) = " << Q(25, 30) << endl; // Example test case
    cout << "Q(20, 5) = " << Q(20, 5) << endl;   // Additional test case
    cout << "Q(15, 10) = " << Q(15, 10) << endl; // Additional test case
    cout << "Q(5, 10) = " << Q(5, 10) << endl;   // Additional test case
    return 0;
}
